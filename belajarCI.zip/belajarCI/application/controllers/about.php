<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		$data['nama'] = "Muhammad Iko Wiryadirja";
		$data['nim'] = "1541180004";
		$data['jurusan'] = "D IV - Teknologi Informasi";
		$data['program_studi'] = "Teknik Informatika";
		$data['ttl'] = "Malang, 10 Januari 1997";
		$this->load->view('about',$data);		
	}

}

/* End of file about.php */
/* Location: ./application/controllers/about.php */