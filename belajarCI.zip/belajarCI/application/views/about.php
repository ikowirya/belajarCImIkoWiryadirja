<!DOCTYPE html>
<html lang="">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About</title>

    <!-- Bootstrap CSS -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <nav class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Latihan Code Igniter</a>
        </div>
    
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="<?php echo site_url()?>/home">Home</a></li>
            <li class="active"><a href="<?php echo site_url()?>/about">About</a></li>
            <li><a href="<?php echo site_url()?>/contact">Contact</a></li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </div>
    </nav>
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>About</th>
          </tr>
        </thead>
        <tbody>
         <tr>
            <td class="info">NIM</td>
            <td class="info"><?php echo $nim; ?></td>
          </tr>
          <tr>
            <td class="success">Nama</td>
            <td class="success"><?php echo $nama; ?></td>
          </tr>
          <tr>
            <td class="active">TTL</td>
            <td class="active"><?php echo $ttl; ?></td>
          </tr>
          <tr>
            <td class="warning">Jurusan</td>
            <td class="warning"><?php echo $jurusan; ?></td>
          </tr>
          <tr>
            <td class="danger">Program Studi</td>
            <td class="danger"><?php echo $program_studi; ?></td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- jQuery -->
    <script src="//code.jquery.com/jquery.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  </body>
</html>